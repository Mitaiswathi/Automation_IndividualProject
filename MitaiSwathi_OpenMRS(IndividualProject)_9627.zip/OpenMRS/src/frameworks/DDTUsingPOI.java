package frameworks;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom.OpenMRS;


public class DDTUsingPOI {

	public static void main(String[] args) throws Exception
	{
		//store Excel file path
				FileInputStream file=new FileInputStream("./DDTUsingPOI.xlsx");
				//JVM will reach to Excel File
				XSSFWorkbook w=new XSSFWorkbook(file);
				XSSFSheet s=w.getSheet("DataDriven");

				//To store total no. of row
				int rowsize =s.getLastRowNum();
				System.out.println("No. of credentials: "+rowsize);

				//Launch Browser
				System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
				WebDriver driver=new ChromeDriver();

				//Create object of POM class
				OpenMRS o=new OpenMRS();

				//For loop
				for(int i=1;i<=rowsize;i++)
				{
					//store username and password in variables
					String username =s.getRow(i).getCell(0).getStringCellValue();
					String password =s.getRow(i).getCell(1).getStringCellValue();

					//Display pair of credential on console
					System.out.println(username+"\t\t"+password);

					//Handle exception(Invalid exception)
					try
					{
						//Login Script
						o.getUrl(driver);
						o.maximizeBrowser(driver);
				        Thread.sleep(2000);
				        o.getUrl(driver);
				        Thread.sleep(2000);
				        o.enterUsername(driver,username);
				        Thread.sleep(2000);
				        o.enterPassword(driver,password);
				        Thread.sleep(2000);
				        o.clickOnLocation(driver);
				        Thread.sleep(2000);
				        o.clickOnLogin(driver);
				        Thread.sleep(2000);
				        o.clickOnLogout(driver);
				        Thread.sleep(2000);
				        o.closeBrowser(driver);

						//Update testResult
						System.out.println("Valid credentials");
						System.out.println("");
						s.getRow(i).createCell(2).setCellValue("Valid Credential");
					}
					catch(Exception e)
					{
						System.out.println("Invalid credentials");
						System.out.println("");
						s.getRow(i).createCell(2).setCellValue("Invalid Credential");
					}

				}
				//write TestResult on ExcelSheet
				FileOutputStream out=new FileOutputStream("./DDTUsingPOI.xlsx");
				w.write(out);

				//close browser
				driver.close();

	}

}
