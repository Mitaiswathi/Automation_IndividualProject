package frameworks;

import org.testng.annotations.Test;

import pom.OpenMRS;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DDTUsingTestNG
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() 
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}

	@Test(dataProvider = "dp")
	public void openMRS(String usn, String pwd) throws Exception 
	{
		OpenMRS o=new OpenMRS();
		o.maximizeBrowser(driver);
		Thread.sleep(2000);
		o.getUrl(driver);
		Thread.sleep(2000);
		o.enterUsername(driver,usn);
		Thread.sleep(2000);
		o.enterPassword(driver,pwd);
		Thread.sleep(2000);
		o.clickOnLocation(driver);
		Thread.sleep(2000);
		o.clickOnLogin(driver);
		Thread.sleep(2000);
		o.clickOnLogout(driver); 
	}

	@DataProvider
	public Object[][] dp() 
	{
		return new Object[][] {
			new Object[] { "Admin", "Admin123" },
			new Object[] { "Swathi", "swathi123" },
			new Object[] { "Mitai", "mitai123" },
			new Object[] { "admin", "admin123" },
			new Object[] { "System", "system123" },
			new Object[] { "Admin", "admin123" },

		};
	}

	@AfterTest
	public void afterTest() 
	{
		driver.close();
	}

}
