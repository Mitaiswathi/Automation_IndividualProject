package basicPrograms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import pom.OpenMRS;

public class Mouse_Hover {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		OpenMRS o=new OpenMRS();
		o.maximizeBrowser(driver);
        Thread.sleep(2000);
        o.getUrl(driver);
        Thread.sleep(2000);
        o.enterUsername(driver,"Admin");
        Thread.sleep(2000);
        o.enterPassword(driver,"Admin123");
        Thread.sleep(2000);
        o.clickOnLocation(driver);
        Thread.sleep(2000);
        o.clickOnLogin(driver);
        Thread.sleep(2000);
        driver.get("https://demo.openmrs.org/openmrs/uicommons/styleGuide.page");
      
        
        Actions a=new Actions(driver);
        List<WebElement> ls= driver.findElements(By.xpath("/html/body/div[2]/aside/section/ul[1]/li"));
        int size=ls.size();
        System.out.println(size);
        for(int i=1;i<=size;i++)
        {
        	System.out.println(driver.findElement(By.xpath("/html/body/div[2]/aside/section/ul[1]/li["+i+"]")).getText());
        	Thread.sleep(2000);
            a.moveToElement(driver.findElement(By.xpath("/html/body/div[2]/aside/section/ul[1]/li["+i+"]"))).click().perform();
        }
        driver.close();
	};

}
