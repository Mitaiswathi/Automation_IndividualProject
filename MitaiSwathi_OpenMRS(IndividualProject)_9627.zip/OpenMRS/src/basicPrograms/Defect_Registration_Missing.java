package basicPrograms;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Defect_Registration_Missing 
{

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
	       WebDriver driver=new ChromeDriver();
	       driver.manage().window().maximize();
	       driver.manage().deleteAllCookies();
	       
	       driver.get("https://demo.openmrs.org/openmrs/login.htm");
	       Thread.sleep(2000);
	       TakesScreenshot ts=(TakesScreenshot)driver;
			File src=ts.getScreenshotAs(OutputType.FILE);
			Thread.sleep(2000);
			File des=new File(".//Defect_Screenshot//missingRegistration.png");
			Thread.sleep(2000);
			FileUtils.copyFile(src,des);
			driver.close();

	}

}
