package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebPage_TitleVerification {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		Thread.sleep(2000);

		String acceptedTitle="orygin";
		String actualTitle=driver.getTitle();
		if(actualTitle.equals(actualTitle))
		{
			System.out.println("Title verification passed");
		}
		else
		{
			System.out.println("Title verification failed");
		}
		//Username
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("Admin");
		Thread.sleep(2000);

		//password
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Admin123");
		Thread.sleep(2000);

		//click on location: Registration
		driver.findElement(By.xpath("//*[@id=\"Registration Desk\"]")).click();
		Thread.sleep(2000);

		//login
		driver.findElement(By.xpath("//*[@id=\"loginButton\"]")).click();
		Thread.sleep(2000);

		//Navigation commands
		driver.findElement(By.xpath("//*[@id=\"coreapps-systemadministration-homepageLink-coreapps-systemadministration-homepageLink-extension\"]")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().forward();
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(2000);
		driver.navigate().to("https://demo.openmrs.org/openmrs/referenceapplication/manageApps.page");
		Thread.sleep(2000);
		driver.close();
	}

}
