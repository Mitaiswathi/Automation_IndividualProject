package basicPrograms;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class CrossBrowser_Testing {

	public static void main(String[] args) throws Exception
	{
		System.out.println("Enter 1 for Google chrome.\nEnter 2 for Microsoft edge.\n Enter 3 for Mozilla firefox.");
		Scanner sc=new Scanner(System.in);
		int input= sc.nextInt();
		WebDriver driver=null;
		switch(input)
		{
		case 1:
			System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
			driver= new ChromeDriver();
			break;
		case 2:
			System.setProperty("webdriver.msedge.driver", ".\\BrowserExtension\\msedgedriver.exe");
			driver=new EdgeDriver();
			break;

			//case 3:
			//	System.setProperty("WebDriver.gecko.driver", "C:\\Users\\Sai kumar\\OneDrive\\Documents\\AutomationTesting\\Browser Extension\\geckodriver.exe");
			//   driver=new FireFoxDriver();

			//break;
		default:System.out.println("Invalid input.");
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		Thread.sleep(2000);

		//Username
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("Admin");
		Thread.sleep(2000);

		//password
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Admin123");
		Thread.sleep(2000);

		//click on location: Registration
		driver.findElement(By.xpath("//*[@id=\"Registration Desk\"]")).click();
		Thread.sleep(2000);

		//login
		driver.findElement(By.xpath("//*[@id=\"loginButton\"]")).click();
		Thread.sleep(2000);

		//logout
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
		Thread.sleep(2000);

		driver.close();


	}

}
