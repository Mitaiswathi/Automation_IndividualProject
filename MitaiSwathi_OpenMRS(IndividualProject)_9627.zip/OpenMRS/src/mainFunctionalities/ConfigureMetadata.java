package mainFunctionalities;

import org.testng.annotations.Test;

import pom.OpenMRS;

import org.testng.annotations.BeforeTest;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ConfigureMetadata 
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
	}
	@Test
	public void configureMetadata() throws Exception
	{
		OpenMRS o=new OpenMRS();
		o.maximizeBrowser(driver);
		Thread.sleep(2000);
		o.getUrl(driver);
		Thread.sleep(2000);
		o.enterUsername(driver,"Admin");
		Thread.sleep(2000);
		o.enterPassword(driver,"Admin123");
		Thread.sleep(2000);
		o.clickOnLocation(driver);
		Thread.sleep(2000);
		o.clickOnLogin(driver);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"org-openmrs-module-adminui-configuremetadata-homepageLink-org-openmrs-module-adminui-configuremetadata-homepageLink-extension\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"org-openmrs-module-adminui-manageEncounterRoles-link-org-openmrs-module-adminui-manageEncounterRoles-link-extension\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-encounter-roles\"]/ui-view/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-encounter-roles\"]/ui-view/form/p[1]/input")).sendKeys("sid");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-encounter-roles\"]/ui-view/form/p[2]/textarea")).sendKeys("qad");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-encounter-roles\"]/ui-view/form/p[3]/button[1]")).click();
		Thread.sleep(2000);
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		File des=new File(".//Functionalities_Screenshot//configureMetadata.png");
		Thread.sleep(2000);
		FileUtils.copyFile(src,des);
	}
	@Test
	public void google() throws Exception
	{
		driver.get("https://www.google.com");
		Thread.sleep(2000);

		//search Area
		driver.findElement(By.id("APjFqb")).sendKeys("What is openMRS ");
		Thread.sleep(2000); 

		//search button
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		File des=new File(".//Functionalities_Screenshot//google.png");
		Thread.sleep(2000);
		FileUtils.copyFile(src,des);
	}
	@AfterTest
	public void afterTest()
	{
		driver.close();
	}

}
