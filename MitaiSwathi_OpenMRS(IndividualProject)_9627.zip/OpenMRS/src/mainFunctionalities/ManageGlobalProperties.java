package mainFunctionalities;

import org.testng.annotations.Test;

import pom.OpenMRS;

import org.testng.annotations.BeforeTest;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ManageGlobalProperties 
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		

	}
	@Test(priority=1)
	public void manageGlobalProperties() throws Exception
	{
		OpenMRS o=new OpenMRS();
		o.maximizeBrowser(driver);
		Thread.sleep(2000);
		o.getUrl(driver);
		Thread.sleep(2000);
		o.enterUsername(driver,"Admin");
		Thread.sleep(2000);
		o.enterPassword(driver,"Admin123");
		Thread.sleep(2000);
		o.clickOnLocation(driver);
		Thread.sleep(2000);
		o.clickOnLogin(driver);
		Thread.sleep(2000);
		driver.get("https://demo.openmrs.org/openmrs/coreapps/systemadministration/systemAdministration.page");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"org-openmrs-module-adminui-globalProperties-app\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-system-settings\"]/ui-view/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-system-settings\"]/ui-view/form/p[1]/input")).sendKeys("swetha");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"manage-system-settings\"]/ui-view/form/p[4]/button[1]")).click();
		Thread.sleep(2000);
		
	}
	@Test(priority=2)
	public void findPatientRecord() throws Exception 
	{
		driver.get("https://demo.openmrs.org/openmrs/referenceapplication/home.page");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"coreapps-activeVisitsHomepageLink-coreapps-activeVisitsHomepageLink-extension\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"patient-search-results-table\"]/tbody/tr[1]/td[1]/span")).click();
		Thread.sleep(2000);
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		File des=new File(".//Functionalities_Screenshot//findPatientRecord.png");
		Thread.sleep(2000);
		FileUtils.copyFile(src,des);
		
	}

	@AfterTest
	public void afterTest()
	{
		driver.close();
	}

}
