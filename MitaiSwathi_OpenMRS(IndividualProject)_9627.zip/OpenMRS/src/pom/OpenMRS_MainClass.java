package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenMRS_MainClass {

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        
        OpenMRS o=new OpenMRS();
        o.maximizeBrowser(driver);
        Thread.sleep(2000);
        o.getUrl(driver);
        Thread.sleep(2000);
        o.enterUsername(driver,"Admin");
        Thread.sleep(2000);
        o.enterPassword(driver,"Admin123");
        Thread.sleep(2000);
        o.clickOnLocation(driver);
        Thread.sleep(2000);
        o.clickOnLogin(driver);
        Thread.sleep(2000);
        o.clickOnLogout(driver);
        Thread.sleep(2000);
        o.closeBrowser(driver);

	}

}
